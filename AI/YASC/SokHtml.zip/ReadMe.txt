______________________________________________________________________

SokHtml - A Small Sokoban Report Generator
Version 0.22 - March 10, 2019
Copyright (c) 2001-2019 by Brian Damgaard, Denmark
E-mail: BrianDamgaard@jubii.dk
______________________________________________________________________

Sokoban(r) Registered Trademark of Falcon Co., Ltd., Japan
Sokoban Copyright (c) 1982-2018 by Hiroyuki Imabayashi, Japan
Sokoban Copyright (c) 1989, 1990, 2001-2019 by Falcon Co., Ltd., Japan
______________________________________________________________________

License

SokHtml - A Small Sokoban Report Generator
Copyright (c) 2001-2019 by Brian Damgaard, Denmark

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.
______________________________________________________________________

Trademarks

Company names, brand names and product names are trademarks or registered trademarks of their respective holders.
______________________________________________________________________

Introduction

SokHtml is a small report generator for Sokoban levels. It is a console application, i.e., there is no graphical user interface. The "Usage" section describes how to launch it from the command line.

A template file contains the formatting instructions which define what information to print for each level, and what the layout should be. Despite the name, the program produces plain text files as well as html files. Seen from the point of view of the program, there is no difference. It is all a matter of which formatting instructions the template author puts into the template.

The "Tag Reference" section contains a complete list of the supported formatting tags.

The tags use html syntax so it is easy to blend Sokoban related tags and normal html format tags in a template. This document is not an introduction to html syntax but briefly, a tag pair encloses and describes a section of text in a document. The tag pair syntax is <tag ...> ... </tag>. An unpaired tag is written as <tag .../>. A few tags like <br> are unpaired and don't need or don't have a closing "/" character.

At the end of this document there are three example templates. 

The first template generates a list of best found solutions which haven't been optimized by an optimizer. 

The second template generates a list of new solutions to export to a Sokoban database, timestamping the listed solutions with the current date so they don't appear on the list again in future runs. Based on these timestamps, another template could, for instance, produce a list of all solutions exported a given year.  

The third template merges a new and an old version of a Sokoban database. Levels in the new version are updated with notes and solutions from matching levels in the old version. New levels, i.e., levels not found in the old version of the database, are marked as such by timestamping them with the current date, and a log file with these new levels is produced.
______________________________________________________________________

Usage

SokHtml <template> <file, folder, "-"> <output> [options]

Template: 
The name of the template file with the formatting instructions. 

File or folder: 
Optional name of a Sokoban level file or a folder with Sokoban level files to be processed. A "-" signals that the files to be processed are specified in the template instead of the command line.

Output: 
Optional name of the output file. If this parameter is omitted, and if the template doesn't contain an output file name either, then one output file is produced for each processed Sokoban level file. This output file has the same name as the level file, except that the file extension has been changed to ".htm" no matter whether the output file is a plain text file or an html file. Existing files are overwritten with no warnings.
    
Options:
-help : Shows program information and parameters on the screen.
______________________________________________________________________

Terminology

In the tag reference, the phrase "it is an error" indicates that the program does not handle the situation gracefully, and that it is up to the user to avoid that situation.
______________________________________________________________________

Tag Reference

Tags and parameter names are case sensitive.

Control Tags
  <#file="..."/>
  <#folder="..."> ... </#folder>
  <#if ...> ... </#if>
  <#Level ...> ... </#Level>
  <#linebreak="..."> ... </#linebreak>
  <#merge .../>
  <#output="..."/>
File Property Tags
  <#FileName .../>
  <#FileNotes .../>
  <#LevelCount/>
  <#Name/> (when outside the #Level section)
  <#Notes .../> (when outside the #Level section)
Level Property Tags
  <#Board .../>
  <#BoxCount/>
  <#FloorCount/>
  <#Height/>
  <#LevelNo/>
  <#Name .../>  (when inside #Level but outside solutions)
  <#Notes .../> (when inside #Level but outside solutions)
  <#PushesLowerBound .../>
  <#Solution/Moves ...> ... <#/Solution/Moves>
  <#Solution/Pushes ...> ... <#/Solution/Pushes>
  <#WallCount/>
  <#Width/>
Solution Property Tags
  <#BoxChanges/>
  <#BoxLines/>
  <#Moves/>
  <#Name/> (when inside a solution section)
  <#Notes .../>  (when inside a solution section)
  <#PusherLines/>
  <#PushingSessions/>
  <#Pushes/>
  <#Solution .../>
Function Tags
  <#Iota .../>
  <#StringCopy .../>
  <#SyntaxTree .../>
Other Tags
  <!-- ... -->


Tags Ordered Alphabetically

____________
<!-- ... -->
Defines a comment in the template. Comments do not appear in the output file. Comments cannot be nested.

_____________
<#Board .../>
Returns the level board as a text string. The tag accepts the optional parameters floor="...", outside="...", version="...", format="...", linebreak="...", top="...", left="...", bottom="...", right="...", and border="...".

The floor parameter controls what to print for empty non-goal floor squares on the board. The default value is "-" instead of a space character because it makes it easier for a human reader to see how many floor squares there are in a row.

The outside parameter controls what to print for empty squares which the pusher cannot ever reach. The default value is "_" instead of a space character.

The version parameter value "normalized" denotes a normalized version of the board.  

The format parameter value "HB64" (Huffman-Base64) outputs a lossless compression version of the board instead of the board itself.

The format parameter value "MD5" outputs the MD5 hash function value for the board instead of the board itself. The output value is influenced by the floor, outside, and linebreak parameters.

The linebreak parameter works like the #linebreak tag, but limited in scope to the board.

The top, left, bottom, and right parameter values define a bounding box for cropping the board. The values are 1-based, top and left are inclusive, bottom and right are exclusive. If not specified, the values default to 1, 1, board height + 1, and board width + 1 respectively.

Implementation limitation: Cropping the board by means of the top, left, bottom, and right parameters does not work together with the version parameter value "normalized".

The border parameter values "true" and "yes" turn empty border squares into walls, if this is necessary to avoid that the player can reach the edge of the board. Please note that border squares with goals, boxes, or the player itself are left untouched, so there is no guarantee that the player cannot reach the edge.

______________
<#BoxChanges/>
Returns the number of box changes in the solution.

____________
<#BoxLines/>
Returns the number of box lines in the solution.

____________
<#BoxCount/>
Returns the number of boxes on the board.

____________
<#DateTime/>
Returns the current date and time as a text string in the format "yyyy-mm-dd  hh:mm:ss".

______________
<#file="..."/>
Specifies a level file or a group of level files to be processed. The specified file path contains an optional directory name followed by a file name, optionally with "*" and "?" wildcard characters. 

Example: <#file="c:\\folder\\subfolder\\*.*"/> specifies all files in the "c:\folder\subfolder" directory. Note that it is necessary to write "\\" to produce a "\" in the evaluated value.

If the file path isn't an absolute path, and if it is inside a #folder tag pair, then the file path is relative to the directory specified by the #folder tag. If the file path isn't an absolute path, and if it isn't inside a #folder tag pair, then the file path is relative to the current working directory.

The #file, #folder, and #output tags are processed only if they are located in the template header section, and only once, meaning they are subject to conditional evaluation under the control of #if tags in a limited form. It is an error to specify file paths and folder paths longer than the Windows constant MAX_PATH - 1.

________________
<#FileName .../>
Returns the name of the level file. The tag accepts an optional format="..." parameter.

Three special character sequences are recognized in the format parameter value. %d expands to the folder name (directory name), without a trailing path delimiter. %f expands to the file name without folder name and file extension. %e expands to the file extension without a period prefix. The default format value is "%f".

Example: <#FileName format="%d\\%f.%e"/> returns the complete file path, with folder, file name, and file extension. Note that it is necessary to write "\\" to produce a "\" in the evaluated value.

_________________
<#FileNotes .../>
Returns or updates file notes information. See #Notes for parameter options.

______________
<#FloorCount/>
Returns the number of floor squares on the board. Goal squares are included, unreachable floor squares are excluded.

______________________________
<#folder="..."> ... </#folder>
In the form with only a start tag, i.e., "<#folder="..."/>, all files in the specified folder are scanned for levels to be processed. 

In the form with both a start tag and an end tag, the files in the folder are not scanned. Instead, the #folder tag makes file paths in <#file="..."/> tags inside the #folder tag relative to the specified folder, unless the file path itself is an absolute path. The full file path is constructed by concatenating the folder name from the #folder tag and the path and file name from the #file tag, automatically adding a path delimiter character in between, if necessary.

Note that it is necessary to write "\\" to produce a "\" in the evaluated value. To specify the current working directory, write folder="".

The #file, #folder, and #output tags are processed only if they are located in the template header section, and only once, meaning they are subject to conditional evaluation under the control of #if tags in a limited form. It is an error to specify file paths and folder paths longer than the Windows constant MAX_PATH - 1.

__________
<#Height/>
Returns the number of rows on the board.

____________________
<#if ...> ... </#if>
The #if tag parameters must be an expression consisting of either a single operand or an "operand relation operand" triad. The body of the #if tag is only processed if the expression evaluates to "true". 

A single operand expression evaluates to "false" if it is the empty text string or the integer 0; everything else evaluates to "true".

The relation operator is = (equal), == (equal), != (not equal), "<" (less), "<=" (less or equal), ">" (greater), or ">=" (greater or equal). The double quotes around some of the operators are necessary to prevent conflicts with other html tags in the template.

The operands are either integers or text strings. Text string comparisons are case insensitive. If one operand is an integer and the other is a text string, then the integer value is converted to a text string before the comparison. If a text string is enclosed by double quotes or single quotes then the enclosing characters are removed before the evaluation.

____________
<#Iota .../>
Returns or sets the value of the built-in Iota variable. The tag accepts the optional parameters value="..." and step="...".

With no value="..." parameter, the tag returns the current Iota value and increments the value by the current step value. With no value="..." parameter, but with a step="..." parameter, it is the new step value which is used for incrementing the Iota value. Overflows and underflows are not detected. The default Iota value is 1.

With a value="..." parameter, the tag returns the empty text string after setting the Iota variable to the specified value, which must be an integer.

The step="..." parameter sets the step value, which must be an integer. The default value is 1. 

__________________________
<#Level ...> ... </#Level>
A #Level tag at the top level of the template denotes which part of the template to apply to each level. Everything before and after this #Level section is the header and footer section respectively. The header and footer sections can contain file information tags, e.g., #FileName and #FileNotes tags. It is an error to have more than one top level #Level tag in the template. Inside the #Level section, there can be other #Level tags as a means to get access to level notes from inside solution sections of the template, where the #Notes tag would refer to the solution notes rather than the level notes.

The top level #Level tag accepts two optional parameters, a file="..." parameter, which has the effect that each level is exported to its own file, and an if-exists="..." parameter, which specifies what to do if a file of the given name already exists.

The file parameter value specifies how to construct the file names. Four special character sequences are recognized. %d expands to the folder name (directory name) of the input level file, without a trailing path delimiter. %f expands to the input level file name without path and extension. %n expands to the current level name. %# expands to the current level number, and  accepts two optional prefix parameters. The full form of %# is %w,p#, where "w" is an optional minimum width, and "p" is an optional left padding character which defaults to space.

The if-exists parameter value must be "new-version" or "supersede". The former creates a new file version with a higher version number. The latter replaces the existing file with the new file. The old file is not destroyed until the new file is successfully saved. The default if-exists parameter value is "new-version".

Example: <#Level file="%d\\%f\\%f %4,0# - %n.sok" if-exists="supersede" linebreak="CRLF"> ... </#Level> exports levels to files with file names like "folder\filename\filename 0012 - levelname.sok". Note that it is necessary to write "\\" to produce a "\" in the evaluated value.

______________
<#LevelCount/>
Returns the number of levels in the level file.

___________
<#LevelNo/>
Returns the level number of the current level. The numbers are 1-based, i.e., the first level in the file has level number 1.

____________________________________
<#linebreak="..."> ... </#linebreak>
Specifies how to expand <br> tags. The parameter values CR, LF, CRLF, and LFCR denote the indicated "carriage return" and "linefeed" characters. All other values are taken literally. 

In the form with only a start tag, i.e., "<#linebreak="..."/>, the value is used for all line break expansions which are not shadowed by a <#linebreak="..."> ... </#linebreak> tag pair.

In the form with both a start tag and an end tag, the value is used inside the tag pair for all line break expansions which are not shadowed by other #linebreak tag pairs.

No physical line break characters are copied from the template file to the output file. Instead, the template author must write <br> tags in the template to specify where to put line breaks in the output file, and combine it with a <#linebreak="..."/> tag to specify how these <br> tags should be expanded.

For convenience, some template tags produce a terminating line break:
1. #Board
2. #Solution
3. #Notes and #FileNotes, when they are used for retrieving the notes in their entirety

These tags can produce multiple lines separated by line breaks. If the tag happens to produce an empty text, e.g., if there is no solution to print for the #Solution tag, and if the tag didn't always produce a terminating line break for consistency, then the template writer wouldn't know how many line breaks to specify for accurate spacing in the output file.

These tags accept an optional line break parameter, so the actual output doesn't necessarily contain physical line breaks. For instance, the #Solution tag can produce the solution as a single text string this way: <#Solution linebreak=""/>. Adding a <br> tag makes the output advance to the next line: <#Solution linebreak=""/><br>.

_____________
<#merge .../>
Merges levels, solutions, and notes from another file into the current level file. The tag accepts two mandatory parameters, file="...", and none="...". 

The file="..." parameter specifies the name of the other level file. Three special character sequences are recognized in the file parameter value. %d expands to the folder name (directory name) of the input level file, without a trailing path delimiter. %f expands to the input level file name without path and extension. %e expands to the file extension without a period prefix.

Example: <#merge file="%d\\old\\%f.%e" none=""/> merges a file with an identical name located in the subfolder "old". Note that it is necessary to write "\\" to produce a "\" in the evaluated value.

The none="..." parameter value specifies an error message to display if the other file does not exist. none="" signals that non-existent files should be ignored.

The merge tag is meant as a means to transfer data from an old version of a level file to a new version. The current level file is the new version, and the file="..." parameter specifies the old version. For matching levels, the level notes from the old version overwrites the new level notes, the rationale being that since notes cannot be merged programmatically, it is best to keep the old notes which presumably contains the more valuable information in form of personal notes, various timestamps, statistics, etc. 

A #merge tag is processed only if it is located in the template header section. It is an error to specify file paths and folder paths longer than the Windows constant MAX_PATH - 1.

_________
<#Moves/>
Returns the number of moves in the solution.

____________
<#Name .../>
Returns the name of the solution, the level, or the file depending on the context. Only level names take one of the optional parameters after="..." and before="...". The first drops a prefix, the second drops a suffix. The full name is returned if the specified parameter value isn't a part of the name.

_____________
<#Notes .../>
Without a key="..." parameter, the tag accepts optional linebreak="..." and none="..." parameters and returns the notes in their entirety.

With a key="..." parameter but without a value="..." parameter, the tag accepts an optional none="..." parameter, looks up the key-value pair in the notes and returns the value, defaulting to an empty text string.

With a key="..." parameter and a value="..." parameter, the tag updates the specified key-value pair in the notes. To delete a key-value pair, write value="". The return value is an empty text string, i.e., nothing is written to the output file. It is only the level file which is updated.

The #Notes tag refers to level notes, solution notes, or file notes depending on the context. In the template header and footer sections, outside the top level #Level tag, it refers to the file notes. Inside a #Level tag, and not shadowed by one of the solution tags, it refers to the level notes. Inside one of the solution tags, and not shadowed by a #Level tag or another solution tag, it refers to the solution notes.

________________
<#output="..."/>
Directs all output to a file with the specified name. If a file already exists with the same name, it will be overwritten with no warning.

To suppress output and process level files for side effects only, write #<output=""/>.

The #file, #folder, and #output tags are processed only if they are located in the template header section, and only once, meaning they are subject to conditional evaluation under the control of #if tags in a limited form. It is an error to specify file paths and folder paths longer than the Windows constant MAX_PATH - 1.

_______________
<#PusherLines/>
Returns the number of pusher lines in the solution.

___________________
<#PushingSessions/>
Returns the number of pushing sessions in the solution.

__________
<#Pushes/>
Returns the number of pushes in the solution.

________________________
<#PushesLowerBound .../>
Returns the lower bound of the number of pushes for a push-optimal solution, or -1 or -2 to indicate odd or even parity respectively for a push-optimal solution. The parity is returned if the lower bound calculation doesn't succeed. 

There are several reasons why the calculation can fail. The calculation time may exceed the time limit. The level may exceed the built-in 1000 boxes limit for the calculation. The level may be unsolvable.

The tag accepts the optional parameters version="..." and time="...".

The version parameter value "normalized" denotes a normalized version of the board.

The time parameter value denotes the calculation time limit in seconds. The value must be a non-negative integer in the range 0..3600. The default value is 60 seconds.

Please note that this can be a very time-consuming calculation.

________________
<#Solution .../>
Returns the solution moves as a text string. The tag accepts an optional linebreak="..." parameter which works like the #linebreak tag, but limited in scope to the solution. When no line break parameter is specified, the #Solution tag produces text lines of a reasonable length separated by the currently selected line break character sequence.

____________________________________________
<#Solution/Moves ...> ... <#/Solution/Moves>
Denotes a template section to apply to the best found solution, counting moves. The tag accepts an optional none="..." parameter.

If there is no separate best solution, counting pushes, this section is applied to the best solution. 

______________________________________________
<#Solution/Pushes ...> ... <#/Solution/Pushes>
Denotes a template section to apply to the best found solution, counting pushes, if this is a different solution than the best solution, counting moves. The tag accepts an optional none="..." parameter.

__________________
<#StringCopy .../>
Returns a substring of a string. The tag accepts the mandatory parameter value="..." and the four optional parameters after="...", before="...", start="..." and end="...".

The value="..." parameter value contains the source string. With just a value="..." parameter, the function returns a copy of the entire string.

The after="..." parameter and the before="..." parameter drop a prefix and a suffix respectively. They are evaluated first, and in that order. Used in combination with start="..." and end="..." parameters, the start index and the end index are relative to the resulting string.

The start="..." parameter value and the end="..." parameter value contains the 1-based index of the first and the last copied character respectively. The start index is inclusive, the end index is exclusive. The start index defaults to 1, the end index defaults to the length of the string + 1.
 
__________________
<#SyntaxTree .../>
Returns a text string showing the syntactic structure of the template as it has been "understood" by the application. This tag isn't used during a normal run, but it can be useful for debugging a template which doesn't produce the expected output.

The tag accepts an optional linebreak="..." parameter which works like the #linebreak tag, but limited in scope to the syntax tree. 

_____________
<#WallCount/>
Returns the number of wall squares on the board.

_________
<#Width/>
Returns the number of columns on the board.
______________________________________________________________________


Special Level Reader Features

1. Make Level from Moves
If the level reader encounters a solution at a time when a level board is expected, then a board is created based on the moves in the solution.

2. Move Player Back to Start Position
A solution may contain the character "!", signaling that the player must return to the starting position at this point. Sometimes this is useful for assembly of solutions from various sources. 

Implementation limitations: A solution may only contain one "!", and level boards cannot be made from solutions with a "!".

______________________________________________________________________

Example Template 1 of 3

<!-- 
SokHtml Template 
Generates a list of best found solutions which haven't been optimized.

___________
Pseudo code

.....translate all "<br>" tags found in the template
.....to "carriage return" + "linefeed"
.....
.....if the level has an unoptimized solution/moves
........or
........the level has an unoptimized solution/pushes
........then 
........emit level name, board, and notes
........
........if the level has an unoptimized solution/moves
...........then
...........emit solution name, moves, and notes
........
........if the level has an unoptimized solution/pushes
...........then
...........emit solution name, moves, and notes

_____
Notes

The opening <#if ...> can be understood this way: The #if expression is a single operand, and if it evaluates to a non-blank text string or a non-zero integer, then the #if expression value is "true" and the level is printed.

The #if expression consists of a #Solution/Moves section. If the level doesn't have a solution, then this tag returns an empty text string and we're done. If the level has one or more solutions, then this tag returns the best solution/moves. We assume that if the solution has been optimized, then the optimizer has left its mark in form of an "Optimizer=..." key-value pair in the solution notes. If there is no such key-value pair, then we generate the non-empty text string "not optimized" which causes the outer #if comparison to evaluate to "true" and print the level.

The check is repeated, this time for the best solution/pushes. The #Solution/Pushes tag returns an empty text string if there is no separate best solution/pushes, but if there is one, and if it hasn't been optimized, then we again return a non-empty text string "not optimized", so the outer #if comparison evaluates to "true".

Note how the #Solution/Pushes tag here is nested inside the #Solution/Moves tag, so the outcome after checking both solutions is a single unified value, as it must be to fit its purpose as being the single operand of the outer #if expression. 
-->

<#linebreak="CRLF"/>

<#Level>

<#if <#Solution/Moves> 
       <#if "" = <#Notes key="Optimizer"/>>
            not optimized
       </#if>
       <#Solution/Pushes>
         <#if "" = <#Notes key="Optimizer"/>>
              not optimized
         </#if>
       </#Solution/Pushes>
     </#Solution/Moves>>

<#Name/><br>
<#Board/>

<#if "" != <#Notes none=""/>> 
<br><#Notes/>
</#if>

<#Solution/Moves none="">
<#if "" = <#Notes key="Optimizer"/>>
<br>
<#Name/><br>
<#Solution/>
<br>
<#Notes none=""/>
</#if>
</#Solution/Moves>

<#Solution/Pushes none="">
<#if "" = <#Notes key="Optimizer"/>>
<br>
<#Name/><br>
<#Solution/>
<br>
<#Notes none=""/>
</#if>
</#Solution/Pushes>
<br>

</#if>

</#Level>
______________________________________________________________________

Example Template 2 of 3

<!-- 
SokHtml Example Template 
Generates a list of new solutions to export to a Sokoban database, timestamping the listed solutions with the current date so they don't appear on the list again in future runs. 

___________
Pseudo code

.....translate all "<br>" tags found in the template
.....to "carriage return" + "linefeed"
.....
.....if the level has a solution
........then 
........
........if the level has a solution/moves 
...........and
...........the solution hasn't been exported earlier
...........then
...........export the solution
...........mark the solution with export date/time
........
........if the level has a solution/pushes
...........and
...........the solution hasn't been exported earlier
...........then
...........export the solution
...........mark the solution with export date/time

_____
Notes

In <#if <#Solution/Moves> exists </#Solution/Moves>> we don't really need the solution; we only need the #Solution/Moves section to produce something non-blank, so the #if expression evaluates to "true". The word "exists" suffices. It has no special meaning and just happens to make it a little easier for the human reader to understand the code. 

Inside the #Solution/Moves and #Solution/Pushes sections, where the solutions are exported, we want to print the level ID from the level notes. We cannot just use a #Notes tag because it would refer to the solution notes, not the level notes. To get what we want, we put the #Notes tag inside a #Level tag, so #Notes momentarily refers to the level.

The line breaks in the template file are only there to make the template easier to read for the human reader. It is the <br> tags, in combination with the <#linebreak="CRLF"/> tag, which generate line breaks for spacing in the output file.
-->

<#linebreak="CRLF"/>

<#Level>

<#if <#Solution/Moves> exists </#Solution/Moves>>

<!--<#Name/><br>-->

<#Solution/Moves none="">
<#if "" = <#Notes key="Export Date"/>>

<#Level>
<#Notes key="ID" none="ID?"/>
</#Level>

:
<#Solution linebreak=""/><br>
<#Notes key="Export Date" value="<#DateTime/>"/>

</#if>
</#Solution/Moves>

<#Solution/Pushes none="">
<#if "" = <#Notes key="Export Date"/>>

<#Level>
<#Notes key="ID" none="ID?"/>
</#Level>

:
<#Solution linebreak=""/><br>
<#Notes key="Export Date" value="<#DateTime/>"/>

</#if>
</#Solution/Pushes>

</#if>

</#Level>
______________________________________________________________________

Example Template 3 of 3

<!-- 
SokHtml Template 

Merges a new and an old version of a Sokoban level database in form of text files.

Input level files: 
* New version of the text files in "c:\temp"
* Old version of the text files in "c:\temp\old"

Output:
* New version of the database updated with level
  notes and solutions from the old version.
* New levels, i.e., levels appearing in the
  database for the first time, timestamped with 
  the current date and time.
* A log file named "New.txt" in the current folder
  with all new levels, if any.
-->

<!-- Since the output is a text file, we need to specify which characters to use as line breaks.
-->

<#linebreak="CRLF"/>

<!-- All the new level files in the database are located in "c:\temp".
-->

<#folder="c:\\temp"/>

<!-- We want to produce a single log file with all new levels, i.e., all levels appearing in the database for the first time.
-->

<#output="New.txt"/>

<!-- We use the #merge tag to mix in all the level notes and solutions from the earlier versions of the level files. The old versions are in "c:\temp\old". The none="" parameter value ignores non-existent files.
-->

<#merge file="%d\\old\\%f.%e" none=""/>

<!-- Now we come to the #Level section, which is applied to each level.
-->

<#Level>

<!-- If the level doesn't have a "Date - registered" key-value pair in its notes, then this is a new level in the database.
-->

<#if "" = <#Notes key="Date - registered"/>>

<!-- This is a new level in the database. Write the "Date - registered" key-value pair in its notes with the current date and time.
-->

<#Notes key="Date - registered" value="<#DateTime/>"/>

<!-- We also want to produce a log file with all the new levels.
-->

<!-- Since the log file can contain levels from different level files, we better write both the file name and the level name. We use the YASC syntax for it, which is filename\[levelname].
-->

<#FileName/>\\[<#Name/>]<br>

<!-- Finally, we write the board and the level notes properly separated by line breaks.
-->
<#Board/><br>
<#Notes/><br><br>

</#if>

</#Level>
