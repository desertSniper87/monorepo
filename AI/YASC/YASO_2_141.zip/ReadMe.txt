====================================================================
YASO - Yet Another Sokoban Optimizer
Version 2.141 - March 1, 2017
Copyright (c) 2017 by Brian Damgaard, Denmark
E-mail: BrianDamgaard@jubii.dk
====================================================================

Sokoban(r) Registered Trademark of Falcon Co., Ltd., Japan
Sokoban Copyright (c) 1982-2017 by Hiroyuki Imabayashi, Japan
Sokoban Copyright (c) 1989, 1990, 2001-2017 by Falcon Co., Ltd., Japan

License
--------
YASO - Yet Another Sokoban Optimizer
Copyright (c) 2017 by Brian Damgaard, Denmark

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

Credits and acknowledgments
----------------------------
Many people have contributed to this program, and I'm particularly
indebted to:

Matthias Meger for sharing a lot of ideas and for a long-standing
correspondence on solvers, optimizers, and deadlock-detection.

Sebastien Gouezel for inventing the "Vicinity search" optimization
method, and generously sharing information on the method and its
implementation. By sharing his ideas and insights on the subject,
he has made a significant and lasting contribution to the Sokoban
game itself, transcending the implementation of the algorithm in
the YASS optimizer.

The Program
------------
The program can search for improvements of existing solutions. 
Here is an example showing the parameters:

YASO LevelFileName -search optimize -optimize moves

Usage
------
Usage: YASO <filename> [options]

Options:
  -deadlocks <number>                : deadlock-sets complexity level 0-3, default 1
  -fallback  <y|n>                   : optimizer fallback strategy, default "disabled"
  -help                              : this overview
  -level     <number> [ - <number> ] : levels to process, default "all"
  -log                               : save search information to a logfile
  -maxtime   <seconds>               : search limit, default (and max.) 49 days
  -memory    <size>|available (MiB)  : defaults to half of physical memory
  -optimize  <moves|pushes|pushesonly|boxlines/moves|boxlines/pushes> : default "pushes"
  -order     g|p|r|v| : enabled methods: Global, Permutations, Rearran., Vicinity
  -prompt    <no|yes>                : confirm messages, default "yes"
  -quick     <no|yes>                : optimizer quick vicinity-search enabled
  -search    <method>                : optimize (default and only option)
  -threads   0..8                    : number of parallel worker threads
  -vicinity  <number> ...            : vicinity squares per box (maximum 4 boxes)
